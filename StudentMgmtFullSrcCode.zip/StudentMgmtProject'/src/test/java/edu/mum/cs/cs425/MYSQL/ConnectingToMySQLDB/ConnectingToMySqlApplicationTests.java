package edu.mum.cs.cs425.MYSQL.ConnectingToMySQLDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectingToMySqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
