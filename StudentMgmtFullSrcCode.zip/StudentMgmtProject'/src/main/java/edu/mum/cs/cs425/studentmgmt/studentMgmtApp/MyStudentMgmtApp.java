package edu.mum.cs.cs425.studentmgmt.studentMgmtApp;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.studentmgmt.model.Student;
import edu.mum.cs.cs425.studentmgmt.repo.StudentRepository;

@Service
public class MyStudentMgmtApp implements CommandLineRunner {

	@Autowired
	private StudentRepository studentRepository;

	public Student saveStudent(Student s) {

		return studentRepository.save(s);
	}
	
	
	@Override
	public void run(String... args) {
		
//		Student s = new Student("000-61-0001", "Adham", "Mohamed", LocalDate.of(2019, 5, 24));
//		s.setMiddleName("Walid");
//		s.setCgpa(3.45);
//		saveStudent(s);

	}
}
