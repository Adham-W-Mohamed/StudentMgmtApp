package edu.mum.cs.cs425.studentmgmt.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Classroom {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long classroomId;

	@ManyToMany(targetEntity=Student.class, mappedBy = "ClassesToAttend" , cascade=CascadeType.ALL)
	private List<Student> studentsAttendingClass;

	private String buildingName;

	private String roomNumber;

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public List<Student> getStudentsAttendingClass() {
		return studentsAttendingClass;
	}

	public void setStudentsAttendingClass(List<Student> studentsAttendingClass) {
		this.studentsAttendingClass = studentsAttendingClass;
	}

}
