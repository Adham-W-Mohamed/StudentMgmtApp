package edu.mum.cs.cs425.studentmgmt.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import net.bytebuddy.implementation.bind.annotation.Empty;

@Entity
@Table(name = "students")
public class Student {

	public Student() {

	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long studentId;

	private String studentNumber;

	private String firstName;

	private String middleName;

	private String lastName;

	private double cgpa;

	@ManyToMany (targetEntity=Classroom.class, cascade=CascadeType.ALL)
	@JoinTable(name = "Student_Classes")
	private List<Classroom> ClassesToAttend;

	public List<Classroom> getClassesToAttend() {
		return ClassesToAttend;
	}

	public void setClassesToAttend(List<Classroom> classesToAttend) {
		ClassesToAttend = classesToAttend;
	}

	public Transcript getTranscript() {
		return transcript;
	}

	public void setTranscript(Transcript transcript) {
		this.transcript = transcript;
	}

	@OneToOne (targetEntity=Transcript.class, cascade=CascadeType.ALL)
	@JoinColumn(name = "transcript")
	private Transcript transcript;

//	@Temporal(TemporalType.DATE)
	private LocalDate dateOfEnrollment;

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getStudentNumber() {
		return studentNumber;
	}

	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getDateOfEnrollment() {
		return dateOfEnrollment;
	}

	public void setDateOfEnrollment(LocalDate dateOfEnrollment) {
		this.dateOfEnrollment = dateOfEnrollment;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentNumber=" + studentNumber + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", dateOfEnrollment=" + dateOfEnrollment + "]";
	}

	public Student(String studentNumber, String firstName, String lastName, LocalDate dateOfEnrollment) {
		this.studentNumber = studentNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfEnrollment = dateOfEnrollment;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public double getCgpa() {
		return cgpa;
	}

	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

}
