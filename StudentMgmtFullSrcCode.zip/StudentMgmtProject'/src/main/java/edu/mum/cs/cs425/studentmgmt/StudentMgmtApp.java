package edu.mum.cs.cs425.studentmgmt;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.mum.cs.cs425.studentmgmt.model.Classroom;
import edu.mum.cs.cs425.studentmgmt.model.Student;
import edu.mum.cs.cs425.studentmgmt.model.Transcript;
import edu.mum.cs.cs425.studentmgmt.repo.ClassroomRepository;
import edu.mum.cs.cs425.studentmgmt.repo.StudentRepository;
import edu.mum.cs.cs425.studentmgmt.repo.TranscriptRepository;

@SpringBootApplication
public class StudentMgmtApp implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(StudentMgmtApp.class, args);

	}

	@Autowired
	private StudentRepository studentRepository;

	@Autowired
	private TranscriptRepository transcriptRepository;

	@Autowired
	private ClassroomRepository classroomRepository;

	public Student saveStudent(Student s) {

		return studentRepository.save(s);
	}

	public Transcript saveTranscript(Transcript t) {

		return transcriptRepository.save(t);
	}

	public Classroom saveClassRoom(Classroom c) {

		return classroomRepository.save(c);
	}

	@Override
	public void run(String... args) {
		
		Transcript t = new Transcript();
		t.setDegreeTitle("MS Computer Science");
		
		
		Student s = new Student("000-61-0001", "Adham", "Mohamed", LocalDate.of(2019, 5, 24));
		s.setMiddleName("Walid");
		s.setCgpa(3.45);
		s.setTranscript(t);
		
		Student s2 = new Student("001-61-0002", "Ahmad", "Walid", LocalDate.of(2020, 2, 1));
		s2.setCgpa(4.0);
//		s2.setTranscript(t);
		
		Classroom c1 = new Classroom();
		c1.setBuildingName("McLaughlin Building");
		c1.setRoomNumber("M105");
		
		Classroom c2 = new Classroom();
		c2.setBuildingName("veril hall");
		c2.setRoomNumber("47A");
		
		List<Student> students = new ArrayList<Student>();
		students.add(s);
		students.add(s2);
		
		List<Classroom> classes = new ArrayList<Classroom>();
		classes.add(c1);
		classes.add(c2);
		
		c1.setStudentsAttendingClass(students);
		c2.setStudentsAttendingClass(students);
		
		s.setClassesToAttend(classes);
		s2.setClassesToAttend(classes);
		
//		t = saveTranscript(t);
		
		saveStudent(s);
		saveStudent(s2);
		
//		saveClassRoom(c1);
//		saveClassRoom(c2);
//		
		

	}

}
